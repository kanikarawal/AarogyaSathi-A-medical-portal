package com.aarogyasathi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AarogyaSathiApplicationTests {

	@Test
	void contextLoads() {
	}

}
