package com.aarogyasathi.exception;

public class AppointmentException extends Exception{

	public AppointmentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AppointmentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AppointmentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
