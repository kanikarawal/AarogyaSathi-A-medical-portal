package com.aarogyasathi.exception;

public class PatientServiceException extends Exception {

	public PatientServiceException() {
		super();
		
	}

	public PatientServiceException(String message, Throwable cause) {
		super(message, cause);
	
	}

	public PatientServiceException(String message) {
		super(message);
	
	}

	
}
