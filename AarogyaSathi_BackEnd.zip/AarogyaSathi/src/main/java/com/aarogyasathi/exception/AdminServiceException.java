package com.aarogyasathi.exception;

public class AdminServiceException extends Exception{

	public AdminServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AdminServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
