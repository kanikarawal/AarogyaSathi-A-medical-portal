package com.aarogyasathi.exception;


public class DoctorServiceException extends Exception {

	public DoctorServiceException() {
		super();
		
	}

	public DoctorServiceException(String message, Throwable cause) {
		super(message, cause);
	
	}

	public DoctorServiceException(String message) {
		super(message);
	
	}

	
}

