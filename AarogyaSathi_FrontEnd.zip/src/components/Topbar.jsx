export default function Topbar(){
    return (
        
         <div className="d-flex justify-content-center text-center">
          <div className="col-2">
            <img src="1atma-nirbhar-bharat-logo.png" alt="" height="90" />
          </div>
          <div className="col-2">
            <img src="ajadilogo.png" alt="" height="90" />
          </div>
          <div className="col-4">
            <img src="NMC.jpg" alt="" height="90" />
          </div>
          <div className="col-2">
            <img src="Combine_Logo.png" alt="" height="90" />
          </div>
          <div className="col-2">
            <img src="All-govenment-schemes-e1571918781687-700x500.jpg" alt="" height="90" />
          </div>
         </div>
    
    );
  }